"""
Generate a self-signed SSL certificate for the Flask application.

Creates cert.pem and key.pem in the ssl/ directory.
The certificate includes SANs for all hostnames/IPs the app may be accessed from.

Usage:
    python ssl/generate_cert.py
"""
import datetime
import ipaddress
import os

from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa


def generate_self_signed_cert(cert_path, key_path, days_valid=3650):
    """Generate a self-signed certificate with SANs for local development."""
    key = rsa.generate_private_key(public_exponent=65537, key_size=2048)

    subject = issuer = x509.Name([
        x509.NameAttribute(NameOID.COUNTRY_NAME, "NL"),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, "BOMMatcher"),
        x509.NameAttribute(NameOID.COMMON_NAME, "fab-app02"),
    ])

    san = x509.SubjectAlternativeName([
        x509.DNSName("localhost"),
        x509.DNSName("fab-app02"),
        x509.DNSName("fab-app02.faber.local"),
        x509.IPAddress(ipaddress.IPv4Address("127.0.0.1")),
        x509.IPAddress(ipaddress.IPv4Address("192.168.10.14")),
    ])

    now = datetime.datetime.now(datetime.timezone.utc)

    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now)
        .not_valid_after(now + datetime.timedelta(days=days_valid))
        .add_extension(san, critical=False)
        .add_extension(x509.BasicConstraints(ca=True, path_length=0), critical=True)
        .sign(key, hashes.SHA256())
    )

    os.makedirs(os.path.dirname(cert_path), exist_ok=True)

    with open(key_path, "wb") as f:
        f.write(key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.TraditionalOpenSSL,
            encryption_algorithm=serialization.NoEncryption(),
        ))

    with open(cert_path, "wb") as f:
        f.write(cert.public_bytes(serialization.Encoding.PEM))

    print(f"Certificate written to: {cert_path}")
    print(f"Private key written to: {key_path}")
    print(f"Valid for {days_valid} days (until {now + datetime.timedelta(days=days_valid):%Y-%m-%d})")
    print()
    print("SANs included:")
    print("  DNS: localhost")
    print("  DNS: fab-app02")
    print("  DNS: fab-app02.faber.local")
    print("  IP:  127.0.0.1")
    print("  IP:  192.168.10.14")


if __name__ == "__main__":
    ssl_dir = os.path.dirname(os.path.abspath(__file__))
    cert_file = os.path.join(ssl_dir, "cert.pem")
    key_file = os.path.join(ssl_dir, "key.pem")

    if os.path.exists(cert_file) or os.path.exists(key_file):
        answer = input("Certificate files already exist. Overwrite? [y/N]: ").strip().lower()
        if answer != "y":
            print("Aborted.")
            raise SystemExit(0)

    generate_self_signed_cert(cert_file, key_file)
